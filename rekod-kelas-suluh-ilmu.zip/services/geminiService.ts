import { GoogleGenAI } from "@google/genai";
import { ExtraClassSession, Student } from "../types";

export const geminiService = {
  /**
   * Analisis data kehadiran menggunakan Gemini API.
   */
  async analyzeAttendance(sessions: ExtraClassSession[], students: Student[]) {
    // Always initialize GoogleGenAI inside the call context to ensure up-to-date config
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const prompt = `
      Analisis data kehadiran kelas tambahan berikut dan berikan ulasan dalam Bahasa Melayu.
      Murid: ${JSON.stringify(students)}
      Sesi: ${JSON.stringify(sessions)}

      Sila berikan:
      1. Ringkasan trend kehadiran keseluruhan.
      2. Kenal pasti murid dengan tahap ketidakhadiran kritikal.
      3. Cadangan untuk meningkatkan penyertaan murid.
    `;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      // Correctly access the text property directly
      return response.text;
    } catch (error) {
      console.error("Gemini Analysis Error:", error);
      return "Gagal melakukan analisis AI buat masa ini.";
    }
  },

  /**
   * Cadangkan topik pembelajaran seterusnya berdasarkan subjek.
   */
  async suggestTopicPlan(subject: string, previousTopics: string[]) {
    // Always initialize GoogleGenAI inside the call context to ensure up-to-date config
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const prompt = `
      Saya adalah guru bagi subjek ${subject}. 
      Topik terdahulu yang telah diajar dalam kelas tambahan: ${previousTopics.join(', ')}.
      Cadangkan 3 topik relevan untuk kelas tambahan seterusnya dalam Bahasa Melayu.
      Format output dalam bentuk senarai bullet yang kemas.
    `;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      // Correctly access the text property directly
      return response.text;
    } catch (error) {
      console.error("Gemini Suggestion Error:", error);
      return "Gagal mendapatkan cadangan.";
    }
  }
};