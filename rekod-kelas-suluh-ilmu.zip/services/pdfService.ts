import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { ExtraClassSession, Student } from '../types';

export const DRIVE_FOLDER_URL = "https://drive.google.com/drive/folders/1Kaby21wl-ABE9xlt8-t7flJcbckBSyI4?usp=sharing";
const LOGO_URL = "https://i.postimg.cc/xT00xFRQ/logo_sknt.png";

const getBase64ImageFromUrl = async (url: string): Promise<string | null> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.setAttribute('crossOrigin', 'anonymous');
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0);
        resolve(canvas.toDataURL('image/png'));
      } else {
        resolve(null);
      }
    };
    img.onerror = () => {
      console.error("Gagal memuatkan logo untuk PDF:", url);
      resolve(null);
    };
    img.src = url;
  });
};

export const pdfService = {
  async generateSessionReport(session: ExtraClassSession, students: Student[]) {
    try {
      const doc = new jsPDF() as any;
      const primaryColor = [79, 70, 229]; // indigo-600
      const classStudents = students.filter(s => s.grade === session.grade);
      
      const presentCount = session.attendance.filter(a => a.status === 'present').length;
      const totalStudents = classStudents.length;
      const attendancePercentage = totalStudents > 0 ? Math.round((presentCount / totalStudents) * 100) : 0;

      // Muat turun logo menggunakan kaedah Canvas yang lebih stabil
      const logoBase64 = await getBase64ImageFromUrl(LOGO_URL);

      if (logoBase64) {
        // Saiz logo dilaraskan untuk kelihatan lebih profesional (22x22)
        doc.addImage(logoBase64, 'PNG', 15, 10, 22, 22);
      }

      doc.setFontSize(18);
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.setFont("helvetica", "bold");
      doc.text("SK NANGA TEMALAT", 42, 20);
      
      doc.setFontSize(11);
      doc.setTextColor(100);
      doc.setFont("helvetica", "bold");
      doc.text("REKOD KEHADIRAN KELAS SULUH ILMU (KelaSI)", 42, 27);
      
      doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.setLineWidth(0.5);
      doc.line(15, 38, 195, 38);

      doc.setFontSize(10);
      doc.setTextColor(0);
      let currentY = 48;

      const detailsX1 = 15;
      const detailsX2 = 110;

      doc.setFont("helvetica", "bold"); doc.text("SUBJEK:", detailsX1, currentY);
      doc.setFont("helvetica", "normal"); doc.text(session.subject, detailsX1 + 45, currentY);
      
      doc.setFont("helvetica", "bold"); doc.text("TARIKH:", detailsX2, currentY);
      doc.setFont("helvetica", "normal"); doc.text(new Date(session.date).toLocaleDateString('ms-MY'), detailsX2 + 45, currentY);

      currentY += 7;
      doc.setFont("helvetica", "bold"); doc.text("GURU:", detailsX1, currentY);
      doc.setFont("helvetica", "normal"); doc.text(session.teacher, detailsX1 + 45, currentY);

      doc.setFont("helvetica", "bold"); doc.text("KELAS:", detailsX2, currentY);
      doc.setFont("helvetica", "normal"); doc.text(session.grade, detailsX2 + 45, currentY);

      currentY += 7;
      doc.setFont("helvetica", "bold"); doc.text("FOKUS PEMBELAJARAN:", detailsX1, currentY);
      doc.setFont("helvetica", "normal"); doc.text(session.topic, detailsX1 + 45, currentY);

      currentY += 7;
      doc.setFont("helvetica", "bold"); doc.text("PERATUS KEHADIRAN:", detailsX1, currentY);
      doc.setFont("helvetica", "bold"); 
      doc.setTextColor(attendancePercentage >= 80 ? 22 : 180, 100, 50);
      doc.text(`${attendancePercentage}% (${presentCount}/${totalStudents})`, detailsX1 + 45, currentY);
      doc.setTextColor(0);

      currentY += 10;

      const attendanceData = classStudents.map((s, idx) => {
        const record = session.attendance.find(a => a.studentId === s.id);
        const statusText = record?.status === 'present' ? 'HADIR' : 'TIDAK HADIR';
        return [idx + 1, s.name, statusText];
      });

      doc.autoTable({
        startY: currentY,
        head: [['No.', 'Nama Murid', 'Status Kehadiran']],
        body: attendanceData,
        theme: 'striped',
        headStyles: { fillColor: primaryColor, textColor: 255 },
        columnStyles: {
          0: { cellWidth: 15, halign: 'center' },
          2: { cellWidth: 40, halign: 'center' }
        },
        didParseCell: (data: any) => {
          if (data.section === 'body' && data.column.index === 2) {
            if (data.cell.raw === 'HADIR') {
              data.cell.styles.textColor = [22, 163, 74];
              data.cell.styles.fontStyle = 'bold';
            } else {
              data.cell.styles.textColor = [220, 38, 38];
            }
          }
        }
      });

      let nextY = doc.lastAutoTable.finalY + 15;

      if (session.reflection) {
        if (nextY > 250) { doc.addPage(); nextY = 20; }
        doc.setFontSize(11);
        doc.setFont("helvetica", "bold");
        doc.text("REFLEKSI PENGAJARAN:", 15, nextY);
        doc.setFontSize(10);
        doc.setFont("helvetica", "normal");
        const splitText = doc.splitTextToSize(session.reflection, 180);
        doc.text(splitText, 15, nextY + 7);
        nextY += 15 + (splitText.length * 5);
      }

      if (session.image) {
        if (nextY > 160) { doc.addPage(); nextY = 20; }
        doc.setFontSize(11);
        doc.setFont("helvetica", "bold");
        doc.text("GAMBAR AKTIVITI:", 15, nextY);
        try {
          doc.addImage(session.image, 'JPEG', 15, nextY + 5, 180, 100);
        } catch (e) { console.error(e); }
      }

      const pageCount = doc.internal.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(150);
        doc.text(`SK Nanga Temalat - Halaman ${i} / ${pageCount} - Together We Are Stronger`, 105, 285, { align: "center" });
      }

      const fileName = `Rekod_KelaSI_${session.subject}_${session.grade}_${session.date}.pdf`;
      doc.save(fileName);
      return fileName;
    } catch (error) {
      console.error("PDF Error:", error);
      throw error;
    }
  }
};