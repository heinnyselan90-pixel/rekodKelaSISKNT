import React, { useState, useMemo } from 'react';
import { 
  ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LabelList
} from 'recharts';
import { ExtraClassSession, Student } from '../types';
import { geminiService } from '../services/geminiService';
import { CLASSES, SUBJECTS } from '../constants';

interface DashboardProps {
  sessions: ExtraClassSession[];
  students: Student[];
  onNewSession: () => void;
}

interface DashboardStats {
  overallAvgPercentage: number;
  subjectSummary: string;
  monthlyClassChartData: any[];
  trendData: any[];
  perfectAttendanceByGrade: Record<string, Student[]>;
  teacherRanking: { name: string; count: number }[];
  recent: ExtraClassSession[];
  sessionBreakdown: Record<string, Record<string, number>>;
}

const classColors = ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#3b82f6'];

// Warna diselaraskan dengan tema Indigo Sistem
const SCHEDULE_DATA = {
  'ISNIN': {
    color: 'bg-indigo-50/50 text-indigo-900',
    headerColor: 'bg-indigo-400',
    classes: {
      'Tahun 1': { teacher: 'EN. BRYAN', sub: '(SN)' },
      'Tahun 2': { teacher: 'PN. JACLYN', sub: '(SN)' },
      'Tahun 3': { teacher: 'EN. N.M. NAQIYUDDIN', sub: '(BM)' },
      'Tahun 4': { teacher: 'PN. LILY', sub: '(MT)' },
      'Tahun 5': { teacher: 'EN. PATRICK', sub: '(BM)' },
      'Tahun 6': { teacher: 'EN. SANTIAGO', sub: '(BM)' },
    }
  },
  'SELASA': {
    color: 'bg-slate-50 text-slate-900',
    headerColor: 'bg-indigo-500',
    classes: {
      'Tahun 1': { teacher: 'PN. LILY', sub: '(MT)' },
      'Tahun 2': { teacher: 'PN. NURUL / EN. M. ASYRAN', sub: '(BM)' },
      'Tahun 3': { teacher: 'PN. JACLYN / EN. ROBIN SIM', sub: '(SN)' },
      'Tahun 4': { teacher: 'PN. ASMAH', sub: '(BM)' },
      'Tahun 5': { teacher: 'PN. ELIZABETH', sub: '(SN)' },
      'Tahun 6': { teacher: 'EN. AMY', sub: '(MT)' },
    }
  },
  'RABU': {
    color: 'bg-indigo-50/50 text-indigo-900',
    headerColor: 'bg-indigo-600',
    classes: {
      'Tahun 1': { teacher: 'EN. N.M. NAQIYUDDIN', sub: '(BM)' },
      'Tahun 2': { teacher: 'CIK KHEERTHIGA', sub: '(ENG)' },
      'Tahun 3': { teacher: 'PN. GOLDIE', sub: '(ENG)' },
      'Tahun 4': { teacher: 'EN. BRYAN', sub: '(SN)' },
      'Tahun 5': { teacher: 'EN. AMY', sub: '(MT)' },
      'Tahun 6': { teacher: 'PN. HEINNY', sub: '(SN)' },
    }
  },
  'KHAMIS': {
    color: 'bg-slate-50 text-slate-900',
    headerColor: 'bg-indigo-700',
    classes: {
      'Tahun 1': { teacher: 'PN. HEINNY', sub: '(ENG)' },
      'Tahun 2': { teacher: 'EN. ROMEO / PN. LILY', sub: '(MT)' },
      'Tahun 3': { teacher: 'PN. ELNAH / EN. AMY', sub: '(MT)' },
      'Tahun 4': { teacher: 'PN. ELIZABETH', sub: '(ENG)' },
      'Tahun 5': { teacher: 'CIK KHEERTHIGA', sub: '(ENG)' },
      'Tahun 6': { teacher: 'PN. GOLDIE', sub: '(ENG)' },
    }
  }
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-white p-4 rounded-2xl shadow-xl border border-slate-100 min-w-[180px] max-w-[240px]">
        <p className="text-xs font-black text-slate-800 mb-2 border-b border-slate-50 pb-2 flex items-center gap-2">
          <i className="fas fa-calendar-day text-indigo-500"></i> {label}
        </p>
        <div className="space-y-1.5">
          {CLASSES.map((cls, index) => (
            <div key={cls} className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: classColors[index] }}></div>
                <span className="text-[10px] font-medium text-slate-500">{cls}:</span>
              </div>
              <span className="text-[10px] font-bold text-slate-700">{data[cls] || 0}%</span>
            </div>
          ))}
          <div className="mt-1.5 pt-1.5 border-t border-slate-50 flex items-center justify-between">
            <span className="text-[10px] font-bold text-indigo-600 uppercase">Purata:</span>
            <span className="text-xs font-black text-indigo-700">{data['Purata Keseluruhan']}%</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

const Dashboard: React.FC<DashboardProps> = ({ sessions, students, onNewSession }) => {
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const stats = useMemo<DashboardStats | null>(() => {
    if (sessions.length === 0) return null;

    const sessionPercentages = sessions.map(s => {
      const presentCount = s.attendance.filter(a => a.status === 'present').length;
      const totalInClass = students.filter(std => std.grade === s.grade).length || s.attendance.length;
      return (presentCount / totalInClass) * 100;
    });

    const overallAvgPercentage = Math.round(sessionPercentages.reduce((a, b) => a + b, 0) / sessionPercentages.length);

    const sessionBreakdown: Record<string, Record<string, number>> = {};
    CLASSES.forEach(cls => {
      sessionBreakdown[cls] = {};
      SUBJECTS.forEach(subj => {
        sessionBreakdown[cls][subj] = 0;
      });
    });

    const subjectCounts: Record<string, number> = {};
    sessions.forEach(s => {
      const key = s.subject === 'Mathematics (DLP)' ? 'MT' : 
                  s.subject === 'Science (DLP)' ? 'SN' : 
                  s.subject === 'Bahasa Melayu' ? 'BM' : 'BI';
      subjectCounts[key] = (subjectCounts[key] || 0) + 1;

      if (sessionBreakdown[s.grade]) {
        sessionBreakdown[s.grade][s.subject] = (sessionBreakdown[s.grade][s.subject] || 0) + 1;
      }
    });

    const subjectSummary = Object.entries(subjectCounts)
      .map(([subj, count]) => `${subj}: ${count}`)
      .join(' | ');

    const gradeSessionCount: Record<string, number> = {};
    sessions.forEach(s => {
      gradeSessionCount[s.grade] = (gradeSessionCount[s.grade] || 0) + 1;
    });

    const studentAttendanceCount: Record<string, number> = {};
    sessions.forEach(session => {
      session.attendance.forEach(record => {
        if (record.status === 'present') {
          studentAttendanceCount[record.studentId] = (studentAttendanceCount[record.studentId] || 0) + 1;
        }
      });
    });

    const perfectAttendanceByGrade: Record<string, Student[]> = {};
    CLASSES.forEach(grade => {
      const totalSessionsForGrade = gradeSessionCount[grade] || 0;
      if (totalSessionsForGrade > 0) {
        const gradeStudents = students.filter(s => s.grade === grade);
        const perfectStudents = gradeStudents.filter(student => {
          const attended = studentAttendanceCount[student.id] || 0;
          return attended === totalSessionsForGrade;
        });
        if (perfectStudents.length > 0) {
          perfectAttendanceByGrade[grade] = perfectStudents;
        }
      }
    });

    const monthlyClassStats: Record<string, Record<string, { sum: number, count: number }>> = {};
    sessions.forEach(s => {
      const date = new Date(s.date);
      const monthLabel = date.toLocaleDateString('ms-MY', { month: 'short' });
      if (!monthlyClassStats[monthLabel]) monthlyClassStats[monthLabel] = {};
      if (!monthlyClassStats[monthLabel][s.grade]) monthlyClassStats[monthLabel][s.grade] = { sum: 0, count: 0 };
      const presentCount = s.attendance.filter(a => a.status === 'present').length;
      const totalInClass = students.filter(std => std.grade === s.grade).length || s.attendance.length;
      const perc = (presentCount / totalInClass) * 100;
      monthlyClassStats[monthLabel][s.grade].sum += perc;
      monthlyClassStats[monthLabel][s.grade].count += 1;
    });

    const monthOrder = ['Jan', 'Feb', 'Mac', 'Apr', 'Mei', 'Jun', 'Jul', 'Ogo', 'Sep', 'Okt', 'Nov', 'Dis'];
    const sortedMonths = Object.keys(monthlyClassStats).sort((a, b) => monthOrder.indexOf(a) - monthOrder.indexOf(b));

    const monthlyClassChartData = sortedMonths.map(month => {
      const entry: any = { month };
      let totalMonthPerc = 0;
      let monthClassCount = 0;

      CLASSES.forEach(cls => {
        if (monthlyClassStats[month][cls]) {
          const avg = Math.round(monthlyClassStats[month][cls].sum / monthlyClassStats[month][cls].count);
          entry[cls] = avg;
          totalMonthPerc += avg;
          monthClassCount += 1;
        } else {
          entry[cls] = 0;
        }
      });
      
      entry['Purata Keseluruhan'] = monthClassCount > 0 ? Math.round(totalMonthPerc / monthClassCount) : 0;
      return entry;
    });

    return { 
      overallAvgPercentage, 
      subjectSummary,
      monthlyClassChartData, 
      trendData: [],
      perfectAttendanceByGrade,
      teacherRanking: [],
      recent: [...sessions].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 5),
      sessionBreakdown
    };
  }, [sessions, students]);

  const handleAIAnalysis = async () => {
    if (sessions.length === 0) return;
    setIsAnalyzing(true);
    const result = await geminiService.analyzeAttendance(sessions, students);
    setAnalysis(result || "Tiada data tersedia");
    setIsAnalyzing(false);
  };

  const getSubjectIcon = (subj: string) => {
    if (subj.includes('Melayu')) return 'fa-language text-rose-500';
    if (subj.includes('English')) return 'fa-comment-dots text-blue-500';
    if (subj.includes('Mathematics')) return 'fa-calculator text-emerald-500';
    if (subj.includes('Science')) return 'fa-flask text-amber-500';
    return 'fa-book text-indigo-500';
  };

  const perfectStudentsCount = stats ? Object.values(stats.perfectAttendanceByGrade).flat().length : 0;

  return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in duration-500 pb-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-800">Ringkasan Prestasi</h2>
          <p className="text-slate-500 text-xs md:text-sm">Analisis kehadiran dan penglibatan murid terkini.</p>
        </div>
        <div className="text-[10px] font-black text-slate-400 bg-white px-4 py-2 rounded-full border border-slate-100 shadow-sm uppercase tracking-widest flex items-center gap-2">
           <i className="fas fa-clock text-indigo-500"></i> Masa KelaSI: 3.00 – 4.00 Petang
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
        <div className="bg-white p-5 md:p-6 rounded-2xl md:rounded-3xl shadow-sm border border-slate-100 flex items-center gap-4 md:gap-5">
          <div className="w-12 h-12 md:w-14 md:h-14 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600">
            <i className="fas fa-percent text-xl md:text-2xl"></i>
          </div>
          <div>
            <p className="text-slate-500 text-[10px] md:text-sm font-medium uppercase tracking-wider">Kehadiran</p>
            <h4 className="text-2xl md:text-3xl font-bold text-slate-800">{stats?.overallAvgPercentage || 0}%</h4>
          </div>
        </div>

        <div className="bg-white p-5 md:p-6 rounded-2xl md:rounded-3xl shadow-sm border border-slate-100 flex items-center gap-4 md:gap-5">
          <div className="w-12 h-12 md:w-14 md:h-14 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600">
            <i className="fas fa-star text-xl md:text-2xl"></i>
          </div>
          <div>
            <p className="text-slate-500 text-[10px] md:text-sm font-medium uppercase tracking-wider">Murid 100%</p>
            <h4 className="text-2xl md:text-3xl font-bold text-slate-800">
              {perfectStudentsCount} <span className="text-xs md:text-sm text-slate-400 font-medium">/ {students.length}</span>
            </h4>
          </div>
        </div>
        
        <div className="bg-white p-5 md:p-6 rounded-2xl md:rounded-3xl shadow-sm border border-slate-100 flex items-center gap-4 md:gap-5 sm:col-span-2 md:col-span-1">
          <div className="w-12 h-12 md:w-14 md:h-14 bg-rose-50 rounded-full flex items-center justify-center text-rose-600">
            <i className="fas fa-book-open text-xl md:text-2xl"></i>
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-slate-500 text-[10px] md:text-sm font-medium uppercase tracking-wider">Jumlah Sesi</p>
            <h4 className="text-2xl md:text-3xl font-bold text-slate-800">{sessions.length}</h4>
          </div>
        </div>
      </div>

      {/* JADUAL WAKTU KelaSI SECTION - OPTIMIZED FOR FULL WIDTH */}
      <div className="space-y-4">
        <h3 className="text-base md:text-lg font-bold text-slate-800 flex items-center gap-2 px-2">
          <i className="fas fa-calendar-alt text-indigo-500"></i> Jadual Waktu Sesi KelaSI
        </h3>
        <div className="bg-white rounded-[1.5rem] md:rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto custom-scrollbar">
            <table className="w-full text-left border-collapse table-fixed">
              <thead>
                <tr>
                  <th className="p-2 md:p-4 bg-slate-50 border-r border-slate-100 w-[60px] md:w-24">
                    <div className="flex flex-col items-center justify-center text-center">
                      <span className="text-[7px] md:text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">HARI</span>
                      <div className="h-px w-full bg-slate-200 my-1 md:my-2"></div>
                      <span className="text-[7px] md:text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">KELAS</span>
                    </div>
                  </th>
                  {Object.keys(SCHEDULE_DATA).map(day => (
                    <th key={day} className={`p-2 md:p-3 text-center text-white font-black text-[9px] md:text-xs uppercase tracking-widest ${(SCHEDULE_DATA as any)[day].headerColor}`}>
                      {day}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {CLASSES.map((cls) => (
                  <tr key={cls} className="hover:bg-slate-50 transition-colors">
                    <td className="p-2 md:p-3 font-black text-slate-700 bg-slate-50 border-r border-slate-100 text-[9px] md:text-xs uppercase tracking-tighter">
                      {cls}
                    </td>
                    {Object.keys(SCHEDULE_DATA).map(day => {
                      const dayData = (SCHEDULE_DATA as any)[day];
                      const classData = dayData.classes[cls];
                      return (
                        <td key={`${day}-${cls}`} className={`p-1.5 md:p-2 text-center border-r last:border-r-0 border-slate-100 ${dayData.color}`}>
                          <div className="flex flex-col items-center justify-center space-y-0.5 leading-tight">
                            <span className="text-[8px] md:text-[10px] font-black uppercase">
                              {classData.teacher}
                            </span>
                            <span className="text-[7px] md:text-[8px] font-bold opacity-60">
                              {classData.sub}
                            </span>
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-base md:text-lg font-bold text-slate-800 flex items-center gap-2 px-2">
          <i className="fas fa-layer-group text-indigo-500"></i> Pecahan Sesi Direkodkan
        </h3>
        {sessions.length === 0 ? (
          <div className="p-10 text-center bg-white rounded-3xl border border-dashed border-slate-200">
            <p className="text-slate-400 text-sm font-medium">Rekod sesi anda untuk melihat statistik pecahan di sini.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {CLASSES.map((cls) => (
              <div key={cls} className="bg-white p-5 md:p-6 rounded-2xl md:rounded-3xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-center mb-4 pb-3 border-b border-slate-50">
                  <span className="font-black text-slate-800 uppercase tracking-tight text-sm md:text-base">{cls}</span>
                  <span className="text-[9px] font-bold bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full">
                    {(Object.values(stats?.sessionBreakdown[cls] || {}) as number[]).reduce((a, b) => a + b, 0)} SESI
                  </span>
                </div>
                <div className="space-y-2 md:space-y-3">
                  {SUBJECTS.map((subj) => {
                    const count = stats?.sessionBreakdown[cls][subj] || 0;
                    return (
                      <div key={subj} className="flex items-center justify-between group">
                        <div className="flex items-center gap-3">
                          <div className="w-7 h-7 md:w-8 md:h-8 rounded-full bg-slate-50 flex items-center justify-center group-hover:bg-indigo-50 transition-colors">
                            <i className={`fas ${getSubjectIcon(subj)} text-[10px]`}></i>
                          </div>
                          <span className="text-[11px] font-semibold text-slate-600 group-hover:text-slate-900 transition-colors truncate max-w-[100px] md:max-w-none">{subj}</span>
                        </div>
                        <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-md ${count > 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                          {count}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
        <div className="bg-white p-6 md:p-8 rounded-2xl md:rounded-3xl shadow-sm border border-slate-100">
          <h3 className="text-base md:text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
            <i className="fas fa-chart-bar text-indigo-500"></i> Analisis Kehadiran Bulanan
          </h3>
          <div className="h-64">
            {sessions.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={stats?.monthlyClassChartData} margin={{ top: 20, right: 10, left: -25, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="month" stroke="#94a3b8" fontSize={10} axisLine={false} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={10} axisLine={false} tickLine={false} domain={[0, 110]} />
                  <Tooltip content={<CustomTooltip />} cursor={{fill: '#f8fafc'}} />
                  <Bar dataKey="Purata Keseluruhan" fill="#6366f1" radius={[6, 6, 0, 0]} barSize={24}>
                    <LabelList 
                      dataKey="Purata Keseluruhan" 
                      position="top" 
                      style={{ fontSize: '10px', fontWeight: 'bold', fill: '#6366f1' }} 
                      formatter={(value: number) => `${value}%`}
                    />
                  </Bar>
                  <Line type="monotone" dataKey="Purata Keseluruhan" stroke="#1e1b4b" strokeWidth={2} dot={{ r: 3, fill: '#1e1b4b', stroke: '#fff' }} />
                </ComposedChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center opacity-30 italic text-sm">Data belum mencukupi</div>
            )}
          </div>
        </div>

        <div className="bg-white p-6 md:p-8 rounded-2xl md:rounded-3xl shadow-sm border border-slate-100 flex flex-col min-h-[350px]">
          <div className="flex items-center justify-between mb-4 md:mb-6">
            <h3 className="text-base md:text-lg font-bold text-slate-800 flex items-center gap-2">
              <i className="fas fa-robot text-violet-500"></i> Insight AI KelaSI
            </h3>
            <button onClick={handleAIAnalysis} disabled={isAnalyzing || sessions.length === 0} className={`text-[10px] px-3 py-1.5 rounded-full font-bold transition-all flex items-center gap-2 ${isAnalyzing || sessions.length === 0 ? 'bg-slate-100 text-slate-400' : 'bg-violet-50 text-violet-600 hover:bg-violet-100'}`}>
              {isAnalyzing ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-wand-sparkles"></i>}
              {analysis ? 'Analisis Semula' : 'Jana'}
            </button>
          </div>
          <div className={`flex-1 overflow-y-auto custom-scrollbar p-4 md:p-5 rounded-xl md:rounded-2xl border ${analysis ? 'bg-violet-50/50 border-violet-100' : 'bg-slate-50 border-slate-100'}`}>
            {analysis ? (
              <div className="text-[12px] md:text-sm text-slate-700 whitespace-pre-wrap leading-relaxed">{analysis}</div>
            ) : (
              <p className="text-xs md:text-sm text-slate-400 italic">Klik Jana Analisis AI untuk ulasan kehadiran keseluruhan sesi yang telah direkodkan.</p>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
        <div className="bg-white p-6 md:p-8 rounded-2xl md:rounded-3xl shadow-sm border border-slate-100 h-[500px] md:h-[600px] flex flex-col">
          <h3 className="text-base md:text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
            <i className="fas fa-trophy text-amber-500"></i> Wall of Fame (100% Hadir)
          </h3>
          <div className="flex-1 overflow-y-auto custom-scrollbar pr-1 space-y-6">
            {stats && Object.keys(stats.perfectAttendanceByGrade).length > 0 ? (
              Object.entries(stats.perfectAttendanceByGrade).map(([grade, gradeStudents]) => (
                <div key={grade} className="space-y-3">
                  <h4 className="text-[10px] font-black text-indigo-600 uppercase tracking-widest bg-indigo-50 px-3 py-1 rounded-lg inline-block">{grade}</h4>
                  <div className="grid grid-cols-1 gap-2">
                    {(gradeStudents as Student[]).map((student) => (
                      <div key={student.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100 group hover:border-amber-200 transition-colors">
                        <div className="flex items-center gap-3">
                          <div className="w-7 h-7 rounded-full bg-amber-100 flex items-center justify-center text-amber-600">
                            <i className="fas fa-award text-xs"></i>
                          </div>
                          <span className="text-[11px] md:text-sm font-bold text-slate-700 truncate max-w-[150px] md:max-w-none">{student.name}</span>
                        </div>
                        <span className="text-[8px] md:text-[9px] font-black text-emerald-600 bg-emerald-100 px-2 py-0.5 rounded-md">100% HADIR</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center opacity-40">
                <i className="fas fa-user-clock text-3xl mb-3"></i>
                <p className="text-xs font-medium">Tiada murid yang hadir penuh setakat ini.</p>
              </div>
            )}
          </div>
        </div>

        <div className="bg-white p-6 md:p-8 rounded-2xl md:rounded-3xl shadow-sm border border-slate-100 h-[500px] md:h-[600px] flex flex-col">
          <h3 className="text-base md:text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
            <i className="fas fa-list-ul text-indigo-500"></i> Sesi Terkini Direkodkan
          </h3>
          <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pr-1">
            {stats && stats.recent.length > 0 ? (
              stats.recent.map((session) => {
                const presentCount = session.attendance.filter(a => a.status === 'present').length;
                const totalInGrade = students.filter(s => s.grade === session.grade).length;
                const percentage = totalInGrade > 0 ? Math.round((presentCount / totalInGrade) * 100) : 0;
                
                return (
                  <div key={session.id} className="p-3 md:p-4 bg-slate-50 rounded-2xl md:rounded-3xl border border-slate-100 hover:bg-white hover:shadow-xl transition-all flex flex-col sm:flex-row gap-4">
                    <div className="w-full sm:w-20 md:w-24 h-24 sm:h-20 md:h-24 rounded-full bg-indigo-100 flex-shrink-0 overflow-hidden border border-indigo-50">
                      {session.image ? (
                        <img src={session.image} alt="Sesi" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-indigo-300">
                          <i className="fas fa-image text-xl"></i>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start mb-1">
                        <span className="text-[9px] font-black text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md uppercase">
                          {new Date(session.date).toLocaleDateString('ms-MY', { day: '2-digit', month: 'short' })}
                        </span>
                        <span className="text-[9px] font-bold text-slate-500 bg-slate-200 px-2 py-0.5 rounded-md uppercase">
                          {session.grade}
                        </span>
                      </div>
                      
                      <h4 className="font-bold text-slate-800 text-xs md:text-sm mb-1 truncate flex items-center gap-2">
                        <i className="fas fa-book-open text-indigo-400 text-[10px]"></i> {session.subject}
                      </h4>
                      <p className="text-[11px] text-slate-600 font-medium truncate mb-0.5 flex items-center gap-2">
                        <i className="fas fa-chalkboard-teacher text-slate-400 text-[10px]"></i> {session.teacher}
                      </p>
                      <p className="text-[11px] text-slate-500 italic truncate mb-2 flex items-center gap-2">
                        <i className="fas fa-lightbulb text-amber-400 text-[10px]"></i> "{session.topic}"
                      </p>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                        <span className="text-[10px] font-bold text-slate-700">{presentCount}/{totalInGrade} Murid</span>
                        <div className={`text-[9px] font-black px-1.5 py-0.5 rounded-md ${percentage >= 80 ? 'text-emerald-600 bg-emerald-50' : percentage >= 50 ? 'text-amber-600 bg-amber-50' : 'text-rose-600 bg-rose-50'}`}>
                          {percentage}% HADIR
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center opacity-40">
                <i className="fas fa-history text-3xl mb-3"></i>
                <p className="text-xs font-medium">Belum ada sesi yang direkodkan lagi.</p>
                <button onClick={onNewSession} className="mt-4 text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline">Rekod Sesi Pertama Sekarang</button>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="text-center pt-8 border-t border-slate-200 space-y-1">
        <p className="text-[10px] md:text-xs font-black text-indigo-900/20 uppercase tracking-[0.4em] italic">Together We Are Stronger</p>
        <p className="text-[10px] font-medium text-slate-400 tracking-widest uppercase">© 2026 SK Nanga Temalat</p>
      </div>
    </div>
  );
};

export default Dashboard;