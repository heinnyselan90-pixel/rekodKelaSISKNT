import React, { useState, useMemo } from 'react';
import { Teacher } from '../types';

interface TeacherManagementProps {
  teachers: Teacher[];
  setTeachers: React.Dispatch<React.SetStateAction<Teacher[]>>;
}

const TeacherManagement: React.FC<TeacherManagementProps> = ({ teachers, setTeachers }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);
  const [newTeacherName, setNewTeacherName] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  const filteredTeachers = useMemo(() => {
    return teachers
      .filter(t => t.name.toLowerCase().includes(searchTerm.toLowerCase()))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [teachers, searchTerm]);

  const handleAddTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeacherName.trim()) return;
    
    const id = `tea-${Date.now()}`;
    setTeachers(prev => [...prev, { name: newTeacherName, id }]);
    setNewTeacherName('');
    setIsAdding(false);
  };

  const handleUpdateTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTeacher) return;
    
    setTeachers(prev => prev.map(t => t.id === editingTeacher.id ? editingTeacher : t));
    setEditingTeacher(null);
  };

  const handleDeleteTeacher = (id: string) => {
    if (confirm('Adakah anda pasti mahu memadam nama guru ini? Ini tidak akan menjejaskan rekod sesi yang telah disimpan.')) {
      setTeachers(prev => prev.filter(t => t.id !== id));
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-800">Pangkalan Data Guru</h2>
          <p className="text-slate-500 text-xs md:text-sm">Urus maklumat guru SK Nanga Temalat untuk kegunaan sistem.</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-amber-500 text-white px-6 py-2.5 rounded-xl font-bold hover:bg-amber-600 transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2"
        >
          <i className="fas fa-user-plus"></i> Tambah Guru
        </button>
      </div>

      <div className="relative">
        <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <input
          type="text"
          placeholder="Cari nama guru..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-amber-500 outline-none shadow-sm"
        />
      </div>

      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase tracking-widest">Bil.</th>
                <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase tracking-widest">Nama Guru</th>
                <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase tracking-widest text-center">Tindakan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredTeachers.map((teacher, index) => (
                <tr key={teacher.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4 text-sm font-medium text-slate-400">{index + 1}</td>
                  <td className="px-6 py-4 text-sm font-bold text-slate-700">{teacher.name}</td>
                  <td className="px-6 py-4 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <button 
                        onClick={() => setEditingTeacher(teacher)}
                        className="p-2 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-all"
                        title="Edit Nama"
                      >
                        <i className="fas fa-edit text-sm"></i>
                      </button>
                      <button 
                        onClick={() => handleDeleteTeacher(teacher.id)}
                        className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                        title="Padam Guru"
                      >
                        <i className="fas fa-trash-alt text-sm"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredTeachers.length === 0 && (
                <tr>
                  <td colSpan={3} className="px-6 py-12 text-center text-slate-400 italic">
                    Tiada guru ditemui dalam pangkalan data.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Tambah Guru */}
      {isAdding && (
        <div className="fixed inset-0 z-[250] flex items-center justify-center bg-indigo-950/40 backdrop-blur-md p-4">
          <div className="bg-white p-8 rounded-[2rem] shadow-2xl border border-white/20 max-w-md w-full animate-in zoom-in-95">
            <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-3">
              <i className="fas fa-user-plus text-amber-600"></i> Tambah Guru Baharu
            </h3>
            <form onSubmit={handleAddTeacher} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest px-1">Nama Penuh</label>
                <input
                  required
                  type="text"
                  placeholder="Masukkan nama penuh guru"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none font-medium"
                  value={newTeacherName}
                  onChange={(e) => setNewTeacherName(e.target.value)}
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button type="button" onClick={() => setIsAdding(false)} className="flex-1 py-3 font-bold text-slate-400 hover:text-slate-600">Batal</button>
                <button type="submit" className="flex-1 py-3 bg-amber-500 text-white rounded-xl font-bold shadow-lg shadow-amber-500/30 hover:bg-amber-600 active:scale-95 transition-all">Simpan</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Edit Guru */}
      {editingTeacher && (
        <div className="fixed inset-0 z-[250] flex items-center justify-center bg-indigo-950/40 backdrop-blur-md p-4">
          <div className="bg-white p-8 rounded-[2rem] shadow-2xl border border-white/20 max-w-md w-full animate-in zoom-in-95">
            <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-3">
              <i className="fas fa-user-edit text-amber-600"></i> Kemas Kini Nama Guru
            </h3>
            <form onSubmit={handleUpdateTeacher} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest px-1">Nama Penuh</label>
                <input
                  required
                  type="text"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none font-medium"
                  value={editingTeacher.name}
                  onChange={(e) => setEditingTeacher(prev => prev ? { ...prev, name: e.target.value } : null)}
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button type="button" onClick={() => setEditingTeacher(null)} className="flex-1 py-3 font-bold text-slate-400 hover:text-slate-600">Batal</button>
                <button type="submit" className="flex-1 py-3 bg-amber-500 text-white rounded-xl font-bold shadow-lg shadow-amber-500/30 hover:bg-amber-600 active:scale-95 transition-all">Kemas Kini</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeacherManagement;