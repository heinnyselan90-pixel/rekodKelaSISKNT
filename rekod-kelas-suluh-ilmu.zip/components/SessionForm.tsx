import React, { useState, useEffect, useMemo } from 'react';
import { Student, Teacher, ExtraClassSession, AttendanceStatus, AttendanceRecord } from '../types';
import { SUBJECTS, CLASSES } from '../constants';

interface SessionFormProps {
  onSave: (session: ExtraClassSession) => void;
  onCancel: () => void;
  students: Student[];
  teachers: Teacher[];
  initialData: ExtraClassSession | null;
}

const DRAFT_KEY = 'kelasi_session_draft';

const SessionForm: React.FC<SessionFormProps> = ({ onSave, onCancel, students, teachers, initialData }) => {
  const [isManualTeacher, setIsManualTeacher] = useState(false);
  const [formData, setFormData] = useState({
    subject: initialData?.subject || '',
    teacher: initialData?.teacher || '',
    topic: initialData?.topic || '',
    date: initialData?.date || new Date().toISOString().split('T')[0],
    grade: initialData?.grade || '',
    reflection: initialData?.reflection || '',
    image: initialData?.image || '',
  });

  const [attendance, setAttendance] = useState<Record<string, AttendanceStatus>>(() => {
    if (initialData) {
      return initialData.attendance.reduce((acc, curr) => ({ ...acc, [curr.studentId]: curr.status }), {});
    }
    return {};
  });

  const [hasDraft, setHasDraft] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Load draft check on mount
  useEffect(() => {
    if (!initialData) {
      const savedDraft = localStorage.getItem(DRAFT_KEY);
      if (savedDraft) {
        setHasDraft(true);
      }
    }
  }, [initialData]);

  // Auto-save logic
  useEffect(() => {
    if (!initialData) {
      const timer = setTimeout(() => {
        const draft = { formData, attendance };
        localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [formData, attendance, initialData]);

  // Check if initial teacher is in the dynamic teacher list
  useEffect(() => {
    if (initialData?.teacher) {
      const isKnown = teachers.some(t => t.name === initialData.teacher);
      if (!isKnown) {
        setIsManualTeacher(true);
      }
    }
  }, [initialData, teachers]);

  const classStudents = useMemo(() => {
    if (!formData.grade) return [];
    return students.filter(s => s.grade === formData.grade);
  }, [formData.grade, students]);

  useEffect(() => {
    if (formData.grade && !initialData && !hasDraft) {
      const newAttendance: Record<string, AttendanceStatus> = {};
      classStudents.forEach(s => {
        newAttendance[s.id] = 'present';
      });
      setAttendance(newAttendance);
    }
  }, [formData.grade, classStudents, initialData, hasDraft]);

  const handleStatusChange = (studentId: string, status: AttendanceStatus) => {
    setAttendance(prev => ({ ...prev, [studentId]: status }));
  };

  const toggleSelectAll = () => {
    const allPresent = classStudents.every(s => attendance[s.id] === 'present');
    const newStatus: AttendanceStatus = allPresent ? 'absent' : 'present';
    const updatedAttendance = { ...attendance };
    classStudents.forEach(s => {
      updatedAttendance[s.id] = newStatus;
    });
    setAttendance(updatedAttendance);
  };

  const attendancePercentage = useMemo(() => {
    if (classStudents.length === 0) return 0;
    const presentCount = classStudents.filter(s => attendance[s.id] === 'present').length;
    return Math.round((presentCount / classStudents.length) * 100);
  }, [classStudents, attendance]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, image: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTeacherChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    if (val === 'MANUAL_INPUT') {
      setIsManualTeacher(true);
      setFormData(prev => ({ ...prev, teacher: '' }));
    } else {
      setFormData(prev => ({ ...prev, teacher: val }));
    }
  };

  const restoreDraft = () => {
    const savedDraft = localStorage.getItem(DRAFT_KEY);
    if (savedDraft) {
      const { formData: dForm, attendance: dAtt } = JSON.parse(savedDraft);
      setFormData(dForm);
      setAttendance(dAtt);
      setHasDraft(false);
      // Check if teacher needs manual input
      if (dForm.teacher) {
        const isKnown = teachers.some(t => t.name === dForm.teacher);
        if (!isKnown) setIsManualTeacher(true);
      }
    }
  };

  const discardDraft = () => {
    localStorage.removeItem(DRAFT_KEY);
    setHasDraft(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.grade) return alert('Sila pilih kelas');
    if (!formData.teacher.trim()) return alert('Sila masukkan nama guru');
    
    setIsSaving(true);
    const attendanceArray: AttendanceRecord[] = classStudents.map(s => ({
      studentId: s.id,
      status: attendance[s.id] || 'absent'
    }));

    const session: ExtraClassSession = {
      id: initialData?.id || Date.now().toString(),
      ...formData,
      attendance: attendanceArray,
    };

    onSave(session);
    localStorage.removeItem(DRAFT_KEY);
    setIsSaving(false);
  };

  const handleCancelAction = () => {
    if (!initialData) discardDraft();
    onCancel();
  };

  return (
    <div className="max-w-5xl mx-auto pb-12 animate-in slide-in-from-bottom-4 duration-500">
      {hasDraft && (
        <div className="mb-6 bg-indigo-50 border border-indigo-100 p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
              <i className="fas fa-lightbulb"></i>
            </div>
            <div>
              <p className="text-sm font-bold text-indigo-900">Draf Ditemui</p>
              <p className="text-xs text-indigo-600 font-medium">Terdapat maklumat sesi yang belum disimpan sebelum ini.</p>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button 
              type="button" 
              onClick={discardDraft}
              className="flex-1 sm:flex-none px-4 py-2 text-xs font-bold text-slate-400 hover:text-slate-600 transition-colors"
            >
              Abaikan
            </button>
            <button 
              type="button" 
              onClick={restoreDraft}
              className="flex-1 sm:flex-none px-5 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 hover:bg-indigo-700 transition-all active:scale-95"
            >
              Pulihkan Draf
            </button>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl md:rounded-[2.5rem] shadow-xl overflow-hidden border border-slate-100">
        <form onSubmit={handleSubmit}>
          <div className="p-6 md:p-8 border-b border-slate-100 bg-slate-50/50">
            <div className="flex justify-between items-start mb-6">
              <h3 className="text-lg md:text-xl font-bold text-slate-800 flex items-center gap-3">
                <i className="fas fa-file-signature text-indigo-500"></i> Butiran Sesi KelaSI
              </h3>
              {!initialData && (
                <div className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-100 px-3 py-1 rounded-full">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></div>
                  Auto-Simpan Aktif
                </div>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
              <div className="space-y-1.5">
                <label className="text-[10px] md:text-xs font-black text-slate-400 block px-1 uppercase tracking-widest">Subjek</label>
                <select
                  required
                  value={formData.subject}
                  onChange={e => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                  className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
                >
                  <option value="">Pilih Subjek</option>
                  {SUBJECTS.map(sub => <option key={sub} value={sub}>{sub}</option>)}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] md:text-xs font-black text-slate-400 block px-1 uppercase tracking-widest">Nama Guru</label>
                {!isManualTeacher ? (
                  <select
                    required
                    value={formData.teacher}
                    onChange={handleTeacherChange}
                    className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
                  >
                    <option value="">Pilih Nama Guru</option>
                    {teachers.map(t => <option key={t.id} value={t.name}>{t.name}</option>)}
                    <option value="MANUAL_INPUT" className="font-bold text-indigo-600">-- Lain-lain (Taip Manual) --</option>
                  </select>
                ) : (
                  <div className="relative">
                    <input
                      required
                      autoFocus
                      type="text"
                      placeholder="Taip nama anda di sini"
                      value={formData.teacher}
                      onChange={e => setFormData(prev => ({ ...prev, teacher: e.target.value }))}
                      className="w-full px-4 py-3 pr-10 bg-white border border-indigo-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm font-medium"
                    />
                    <button 
                      type="button"
                      onClick={() => {
                        setIsManualTeacher(false);
                        setFormData(prev => ({ ...prev, teacher: '' }));
                      }}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-indigo-400 hover:text-indigo-600"
                      title="Kembali ke senarai"
                    >
                      <i className="fas fa-list-ul"></i>
                    </button>
                  </div>
                )}
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] md:text-xs font-black text-slate-400 block px-1 uppercase tracking-widest">Tarikh</label>
                <input
                  required
                  type="date"
                  value={formData.date}
                  onChange={e => setFormData(prev => ({ ...prev, date: e.target.value }))}
                  className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] md:text-xs font-black text-slate-400 block px-1 uppercase tracking-widest">Pilih Kelas</label>
                <select
                  required
                  value={formData.grade}
                  onChange={e => setFormData(prev => ({ ...prev, grade: e.target.value }))}
                  className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
                >
                  <option value="">Pilih Kelas</option>
                  {CLASSES.map(cls => <option key={cls} value={cls}>{cls}</option>)}
                </select>
              </div>

              <div className="space-y-1.5 md:col-span-2">
                <label className="text-[10px] md:text-xs font-black text-slate-400 block px-1 uppercase tracking-widest">Fokus Pembelajaran</label>
                <input
                  required
                  type="text"
                  placeholder="Contoh: Pengiraan Peratus & Pecahan"
                  value={formData.topic}
                  onChange={e => setFormData(prev => ({ ...prev, topic: e.target.value }))}
                  className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
                />
              </div>
            </div>
          </div>

          {formData.grade && (
            <div className="p-6 md:p-8 bg-white border-b border-slate-100">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                <h3 className="text-lg md:text-xl font-bold text-slate-800 flex items-center gap-3">
                  <i className="fas fa-users-check text-indigo-500"></i> Kehadiran ({formData.grade})
                </h3>
                <div className="flex items-center justify-between sm:justify-end gap-4">
                  <div className="px-3 py-1.5 bg-indigo-50 text-indigo-700 rounded-lg text-xs font-black border border-indigo-100">
                    {attendancePercentage}% HADIR
                  </div>
                  <button type="button" onClick={toggleSelectAll} className="text-[10px] font-black text-indigo-600 hover:text-indigo-800 uppercase tracking-wider underline underline-offset-4">
                    {classStudents.every(s => attendance[s.id] === 'present') ? 'Tiada Hadir' : 'Hadir Semua'}
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
                {classStudents.map(student => (
                  <div 
                    key={student.id} 
                    onClick={() => handleStatusChange(student.id, attendance[student.id] === 'present' ? 'absent' : 'present')}
                    className={`cursor-pointer flex items-center justify-between p-4 rounded-xl md:rounded-2xl border transition-all ${attendance[student.id] === 'present' ? 'bg-emerald-50 border-emerald-200 shadow-sm' : 'bg-slate-50 border-slate-200'}`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`w-5 h-5 rounded flex-shrink-0 flex items-center justify-center border-2 transition-all ${attendance[student.id] === 'present' ? 'bg-emerald-500 border-emerald-500' : 'bg-white border-slate-300'}`}>
                        {attendance[student.id] === 'present' && <i className="fas fa-check text-white text-[8px]"></i>}
                      </div>
                      <span className={`text-xs font-bold truncate ${attendance[student.id] === 'present' ? 'text-emerald-900' : 'text-slate-600'}`}>{student.name}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="p-6 md:p-8 bg-slate-50/30 grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
            <div className="space-y-3">
              <label className="text-[10px] md:text-xs font-black text-slate-400 block px-1 uppercase tracking-widest">Refleksi</label>
              <textarea
                value={formData.reflection}
                onChange={e => setFormData(prev => ({ ...prev, reflection: e.target.value }))}
                placeholder="Tuliskan refleksi sesi pengajaran di sini..."
                className="w-full h-32 px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none resize-none text-sm"
              ></textarea>
            </div>
            <div className="space-y-3">
              <label className="text-[10px] md:text-xs font-black text-slate-400 block px-1 uppercase tracking-widest">Gambar Aktiviti</label>
              <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-200 rounded-xl bg-white p-6 relative group overflow-hidden h-32 transition-colors hover:border-indigo-300">
                {formData.image ? (
                  <>
                    <img src={formData.image} alt="Preview" className="absolute inset-0 w-full h-full object-cover opacity-50" />
                    <button type="button" onClick={() => setFormData(prev => ({...prev, image: ''}))} className="absolute top-2 right-2 w-7 h-7 bg-rose-500 text-white rounded-full flex items-center justify-center shadow-lg z-10">
                      <i className="fas fa-times text-xs"></i>
                    </button>
                  </>
                ) : (
                  <div className="text-center">
                    <i className="fas fa-camera text-2xl text-slate-300 mb-2"></i>
                    <p className="text-[10px] font-bold text-slate-400">Sentuh untuk muat naik</p>
                  </div>
                )}
                <input type="file" accept="image/*" onChange={handleImageUpload} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
              </div>
            </div>
          </div>

          <div className="p-6 md:p-8 border-t border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row gap-3 md:gap-4 items-center justify-end">
            <button type="button" onClick={handleCancelAction} className="w-full sm:w-auto px-8 py-3 rounded-xl font-bold text-slate-500 hover:bg-slate-200 transition-all text-sm order-2 sm:order-1">Batal</button>
            <button type="submit" disabled={isSaving} className="w-full sm:w-auto px-10 py-4 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-600/30 hover:bg-indigo-700 hover:-translate-y-1 transition-all flex items-center justify-center gap-3 disabled:opacity-50 text-sm order-1 sm:order-2">
              {isSaving ? <i className="fas fa-circle-notch fa-spin"></i> : <i className="fas fa-save"></i>}
              Simpan Rekod Sesi
            </button>
          </div>
        </form>
      </div>
      
      {/* Footer Branding Slogan */}
      <div className="text-center pt-8 space-y-1">
        <p className="text-[10px] md:text-xs font-black text-indigo-900/10 uppercase tracking-[0.4em] italic">Together We Are Stronger</p>
        <p className="text-[10px] font-medium text-slate-400 tracking-widest uppercase">© 2026 SK Nanga Temalat</p>
      </div>
    </div>
  );
};

export default SessionForm;