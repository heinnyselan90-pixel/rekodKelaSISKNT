
import React, { useState } from 'react';
import { ExtraClassSession, Student } from '../types';
import { pdfService, DRIVE_FOLDER_URL } from '../services/pdfService';

interface SessionHistoryProps {
  sessions: ExtraClassSession[];
  students: Student[];
  onEdit: (session: ExtraClassSession) => void;
  onDelete: (id: string) => void;
}

const SessionHistory: React.FC<SessionHistoryProps> = ({ sessions, students, onEdit, onDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [generatingId, setGeneratingId] = useState<string | null>(null);
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);
  
  const filteredSessions = sessions.filter(s => 
    s.subject.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.teacher.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.topic.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.grade?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDownloadPDF = async (session: ExtraClassSession) => {
    setGeneratingId(session.id);
    try {
      const fileName = await pdfService.generateSessionReport(session, students);
      // Mesej dikemaskini untuk kejelasan proses 'automatik'
      alert(`Laporan '${fileName}' telah berjaya dijana. Sila muat naik fail yang baru dimuat turun ini ke dalam folder Google Drive SK Nanga Temalat yang akan dibuka sebentar lagi.`);
      window.open(DRIVE_FOLDER_URL, '_blank');
    } catch (error) {
      alert("Gagal menjana PDF.");
    } finally {
      setGeneratingId(null);
    }
  };

  const confirmDelete = () => {
    if (deleteTargetId) {
      onDelete(deleteTargetId);
      setDeleteTargetId(null);
    }
  };

  if (sessions.length === 0) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-center p-10 bg-white rounded-3xl border border-dashed border-slate-300">
         <p className="text-slate-500">Tiada sejarah sesi ditemui.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Custom Delete Confirmation Modal */}
      {deleteTargetId && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center bg-slate-900/60 backdrop-blur-md px-4 animate-in fade-in duration-300">
          <div className="bg-white p-8 rounded-[2.5rem] shadow-2xl border border-slate-100 max-w-sm w-full text-center animate-in zoom-in-95 duration-300">
            <div className="w-20 h-20 bg-rose-50 text-rose-500 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl shadow-inner border border-rose-100">
              <i className="fas fa-trash-alt"></i>
            </div>
            <h3 className="text-2xl font-black text-slate-800 mb-3 tracking-tight">Padam Rekod?</h3>
            <p className="text-slate-500 font-medium mb-8 leading-relaxed">Anda pasti mahu memadamkan rekod ini? Tindakan ini tidak boleh diundur.</p>
            <div className="flex flex-col gap-3">
              <button 
                onClick={confirmDelete}
                className="w-full py-4 bg-rose-500 text-white rounded-2xl font-bold shadow-lg shadow-rose-500/30 hover:bg-rose-600 transition-all active:scale-95 text-base"
              >
                Ya, Padam Rekod
              </button>
              <button 
                onClick={() => setDeleteTargetId(null)}
                className="w-full py-3 rounded-xl font-bold text-slate-400 hover:text-slate-600 transition-all text-sm"
              >
                Batal
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
          <input
            type="text"
            placeholder="Cari mengikut subjek, guru, gred..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm transition-all"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredSessions.map((session) => {
          const present = session.attendance.filter(a => a.status === 'present').length;
          const sessionGradeStudents = students.filter(s => s.grade === session.grade);
          const total = sessionGradeStudents.length || session.attendance.length;
          const percentage = Math.round((present / total) * 100);

          return (
            <div key={session.id} className="bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow overflow-hidden group">
              <div className="flex flex-col md:flex-row">
                <div className={`w-full md:w-2 ${percentage > 80 ? 'bg-emerald-500' : percentage > 50 ? 'bg-amber-500' : 'bg-rose-500'}`}></div>
                <div className="flex-1 p-6 flex flex-col md:flex-row md:items-center gap-6">
                  {session.image && (
                    <div className="w-20 h-20 rounded-2xl overflow-hidden border border-slate-100 flex-shrink-0">
                      <img src={session.image} alt="Session" className="w-full h-full object-cover" />
                    </div>
                  )}
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                        {new Date(session.date).toLocaleDateString('ms-MY', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                      </span>
                      <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded uppercase">{session.grade}</span>
                    </div>
                    <h3 className="text-xl font-bold text-slate-800 mb-1">{session.topic}</h3>
                    <div className="flex items-center gap-4 text-sm text-slate-500">
                      <span className="flex items-center gap-1.5 font-semibold text-slate-600"><i className="fas fa-book-bookmark text-indigo-400"></i> {session.subject}</span>
                      <span className="flex items-center gap-1.5 font-semibold text-emerald-600"><i className="fas fa-percent text-emerald-400"></i> {percentage}%</span>
                      <span className="flex items-center gap-1.5"><i className="fas fa-user-tie text-slate-400"></i> {session.teacher}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-8 md:px-8 md:border-x border-slate-100">
                    <div className="text-center">
                      <p className="text-2xl font-black text-slate-800 leading-tight">{present}/{total}</p>
                      <p className="text-xs font-bold text-slate-400 uppercase">Hadir</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => handleDownloadPDF(session)} title="Jana Laporan & Simpan ke Drive" disabled={generatingId === session.id} className="p-3 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-2xl transition-all disabled:opacity-50">
                      {generatingId === session.id ? <i className="fas fa-circle-notch fa-spin text-lg"></i> : <i className="fas fa-file-pdf text-lg"></i>}
                    </button>
                    <button onClick={() => onEdit(session)} title="Edit Record" className="p-3 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-2xl transition-all"><i className="fas fa-edit text-lg"></i></button>
                    <button onClick={() => setDeleteTargetId(session.id)} title="Delete Record" className="p-3 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-2xl transition-all"><i className="fas fa-trash-alt text-lg"></i></button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SessionHistory;
