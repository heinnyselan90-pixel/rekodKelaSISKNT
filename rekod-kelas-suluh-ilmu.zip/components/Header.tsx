import React from 'react';

interface HeaderProps {
  title: string;
  onMenuClick?: () => void;
}

const Header: React.FC<HeaderProps> = ({ title, onMenuClick }) => {
  return (
    <header className="bg-white border-b border-slate-200 px-4 md:px-8 py-4 md:py-5 flex items-center justify-between z-10 sticky top-0">
      <div className="flex items-center gap-4">
        <button 
          onClick={onMenuClick}
          className="p-2 md:hidden text-slate-500 hover:bg-slate-50 rounded-lg transition-colors"
        >
          <i className="fas fa-bars text-lg"></i>
        </button>
        <h2 className="text-lg md:text-xl font-bold text-slate-800 tracking-tight truncate">{title}</h2>
      </div>
      
      <div className="flex items-center gap-2">
        <div className="hidden sm:flex items-center gap-2">
          <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Sistem Aktif</span>
        </div>
      </div>
    </header>
  );
};

export default Header;