
import React from 'react';

interface SidebarProps {
  currentView: 'home' | 'dashboard' | 'new-session' | 'admin' | 'history' | 'students';
  setView: (view: 'home' | 'dashboard' | 'new-session' | 'admin' | 'history' | 'students') => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView }) => {
  const navItems = [
    { id: 'dashboard', label: 'Papan Pemuka', icon: 'fa-chart-pie' },
    { id: 'new-session', label: 'Rekod Sesi KelaSI', icon: 'fa-plus-circle' },
    { id: 'admin', label: 'Akses Pentadbir', icon: 'fa-user-shield' },
  ];

  const logoUrl = "https://i.postimg.cc/xT00xFRQ/logo_sknt.png";

  return (
    <aside className="flex flex-col h-full w-72 bg-indigo-900 text-white p-6 shadow-xl border-r border-indigo-800/50">
      <div className="flex items-center gap-3 mb-10 px-2 cursor-pointer group" onClick={() => setView('home')}>
        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center overflow-hidden flex-shrink-0 border-2 border-white shadow-md group-hover:scale-105 transition-transform duration-300 p-1">
          <img src={logoUrl} alt="Logo Rekod KelaSI" className="w-full h-full object-contain" />
        </div>
        <h1 className="text-lg font-bold tracking-tight leading-tight group-hover:text-indigo-200 transition-colors">Rekod Kelas Suluh Ilmu (KelaSI)</h1>
      </div>

      <nav className="flex-1 flex flex-col">
        <div className="flex justify-start mb-6 px-1">
          <button
            onClick={() => setView('home')}
            title="Muka Depan"
            className={`w-12 h-12 flex items-center justify-center rounded-2xl transition-all duration-300 ${
              currentView === 'home'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-950/50 ring-2 ring-indigo-400/30'
                : 'text-indigo-300 hover:bg-indigo-800 hover:text-white'
            }`}
          >
            <i className="fas fa-home text-xl"></i>
          </button>
        </div>

        <div className="h-px bg-indigo-800/50 w-full mb-6"></div>

        <div className="flex flex-col gap-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setView(item.id as any)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                currentView === item.id || (item.id === 'admin' && (currentView === 'history' || currentView === 'students'))
                  ? 'bg-indigo-700 text-white shadow-lg shadow-indigo-950/50'
                  : 'text-indigo-200 hover:bg-indigo-800 hover:text-white'
              }`}
            >
              <i className={`fas ${item.icon} w-5 text-center`}></i>
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>

      <div className="mt-auto p-4 bg-indigo-800/50 rounded-2xl border border-indigo-700/50">
        <p className="text-[10px] text-indigo-300 font-bold mb-1 uppercase tracking-widest opacity-70 italic">Together We Are Stronger</p>
        <p className="text-[10px] font-black text-white leading-tight tracking-wider uppercase">SK NANGA TEMALAT, SONG, SARAWAK</p>
      </div>
    </aside>
  );
};

export default Sidebar;
