
import React, { useState, useEffect } from 'react';
import { ExtraClassSession, Student, Teacher } from './types';
import { MOCK_STUDENTS, MOCK_TEACHERS } from './constants';
import Dashboard from './components/Dashboard';
import SessionForm from './components/SessionForm';
import SessionHistory from './components/SessionHistory';
import StudentManagement from './components/StudentManagement';
import TeacherManagement from './components/TeacherManagement';
import Sidebar from './components/Sidebar';
import Header from './components/Header';

const SCHOOL_LOGO_URL = "https://i.postimg.cc/xT00xFRQ/logo_sknt.png";

const App: React.FC = () => {
  // State untuk Sesi
  const [sessions, setSessions] = useState<ExtraClassSession[]>(() => {
    const saved = localStorage.getItem('school_sessions');
    return saved ? JSON.parse(saved) : [];
  });

  // State untuk Murid (Dinamik)
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('school_students');
    return saved ? JSON.parse(saved) : MOCK_STUDENTS;
  });

  // State untuk Guru (Dinamik)
  const [teachers, setTeachers] = useState<Teacher[]>(() => {
    const saved = localStorage.getItem('school_teachers');
    return saved ? JSON.parse(saved) : MOCK_TEACHERS;
  });

  const [view, setView] = useState<'home' | 'dashboard' | 'new-session' | 'admin' | 'history' | 'students' | 'teachers'>('home');
  const [editingSession, setEditingSession] = useState<ExtraClassSession | null>(null);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  const [pendingView, setPendingView] = useState<'admin' | 'history' | 'students' | 'teachers' | null>(null);
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('school_sessions', JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem('school_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('school_teachers', JSON.stringify(teachers));
  }, [teachers]);

  const handleSaveSession = (session: ExtraClassSession) => {
    if (editingSession) {
      setSessions(prev => prev.map(s => s.id === session.id ? session : s));
    } else {
      setSessions(prev => [session, ...prev]);
    }
    setEditingSession(null);
    setView('dashboard');
    setShowSuccessPopup(true);
  };

  const handleEditSession = (session: ExtraClassSession) => {
    setEditingSession(session);
    setView('new-session');
  };

  const handleDeleteSession = (id: string) => {
    setSessions(prev => prev.filter(s => s.id !== id));
  };

  const handleViewChange = (newView: any) => {
    const adminViews = ['admin', 'history', 'students', 'teachers'];
    if (adminViews.includes(newView) && !isAdminAuthenticated) {
      setPendingView(newView);
      setShowPasswordPrompt(true);
    } else {
      setView(newView);
      setShowPasswordPrompt(false);
      setIsMobileMenuOpen(false);
    }
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === 'kelasi123') {
      setIsAdminAuthenticated(true);
      if (pendingView) setView(pendingView);
      setShowPasswordPrompt(false);
      setPasswordInput('');
      setPendingView(null);
      setIsMobileMenuOpen(false);
    } else {
      alert('Kata laluan salah!');
      setPasswordInput('');
    }
  };

  const PasswordPromptUI = () => (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-indigo-950/40 backdrop-blur-md animate-in fade-in duration-300 px-4">
      <div className="bg-white/90 backdrop-blur-2xl p-8 md:p-10 rounded-[2.5rem] shadow-2xl border border-white/40 max-w-sm w-full text-center animate-in zoom-in-95 duration-300">
        <div className="w-20 h-20 bg-indigo-600 text-white rounded-full flex items-center justify-center mx-auto mb-8 text-3xl shadow-lg hover:scale-105 transition-transform">
          <i className="fas fa-lock"></i>
        </div>
        <h3 className="text-2xl font-black text-indigo-900 mb-3 tracking-tight">Akses Terhad</h3>
        <p className="text-slate-500 text-sm mb-8 font-medium leading-relaxed">Sila masukkan kata laluan rasmi untuk mengakses Akses Pentadbir KelaSI.</p>
        <form onSubmit={handlePasswordSubmit} className="space-y-4">
          <input
            type="password"
            autoFocus
            placeholder="Kata Laluan"
            value={passwordInput}
            onChange={(e) => setPasswordInput(e.target.value)}
            className="w-full px-6 py-4 bg-slate-100 border-2 border-slate-100 rounded-2xl focus:border-indigo-500 focus:bg-white outline-none text-center font-bold tracking-widest transition-all text-lg shadow-inner"
          />
          <div className="flex flex-col gap-3 pt-4">
            <button 
              type="submit" 
              className="w-full px-4 py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-xl shadow-indigo-600/30 hover:bg-indigo-700 transition-all active:scale-95 text-base"
            >
              Sahkan Akses
            </button>
            <button 
              type="button" 
              onClick={() => {
                setShowPasswordPrompt(false);
                setPendingView(null);
              }}
              className="w-full px-4 py-3 rounded-xl font-bold text-slate-400 hover:text-slate-600 transition-all text-sm"
            >
              Batal
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  // Admin Hub Component
  const AdminHub = () => (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="text-center md:text-left mb-8">
        <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight">Pusat Kawalan Pentadbir</h2>
        <p className="text-slate-500 font-medium">Sila pilih tugasan pengurusan yang ingin dilakukan.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
        <button 
          onClick={() => setView('history')}
          className="group p-8 md:p-10 bg-white rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl hover:border-indigo-100 transition-all text-left flex flex-col items-start gap-6 relative overflow-hidden active:scale-95"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-bl-[5rem] -mr-8 -mt-8 group-hover:bg-indigo-100 transition-colors"></div>
          <div className="w-16 h-16 bg-indigo-600 text-white rounded-full flex items-center justify-center text-2xl shadow-lg relative z-10 group-hover:scale-110 transition-transform">
            <i className="fas fa-history"></i>
          </div>
          <div className="relative z-10">
            <h3 className="text-xl md:text-2xl font-black text-slate-800 mb-2">Sejarah & Laporan Sesi</h3>
            <p className="text-slate-500 text-xs leading-relaxed">Lihat rekod lama, edit butiran sesi, padam rekod, dan jana laporan PDF rasmi.</p>
          </div>
          <div className="mt-4 flex items-center gap-2 text-indigo-600 font-bold text-[10px] uppercase tracking-widest">
            Buka Sejarah <i className="fas fa-arrow-right group-hover:translate-x-1 transition-transform"></i>
          </div>
        </button>

        <button 
          onClick={() => setView('students')}
          className="group p-8 md:p-10 bg-white rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl hover:border-emerald-100 transition-all text-left flex flex-col items-start gap-6 relative overflow-hidden active:scale-95"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-bl-[5rem] -mr-8 -mt-8 group-hover:bg-emerald-100 transition-colors"></div>
          <div className="w-16 h-16 bg-emerald-500 text-white rounded-full flex items-center justify-center text-2xl shadow-lg relative z-10 group-hover:scale-110 transition-transform">
            <i className="fas fa-users-cog"></i>
          </div>
          <div className="relative z-10">
            <h3 className="text-xl md:text-2xl font-black text-slate-800 mb-2">Pengurusan Murid</h3>
            <p className="text-slate-500 text-xs leading-relaxed">Tambah murid baharu, kemas kini nama murid sedia ada, atau urus data perpindahan.</p>
          </div>
          <div className="mt-4 flex items-center gap-2 text-emerald-600 font-bold text-[10px] uppercase tracking-widest">
            Urus Murid <i className="fas fa-arrow-right group-hover:translate-x-1 transition-transform"></i>
          </div>
        </button>

        <button 
          onClick={() => setView('teachers')}
          className="group p-8 md:p-10 bg-white rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl hover:border-amber-100 transition-all text-left flex flex-col items-start gap-6 relative overflow-hidden active:scale-95 md:col-span-2 lg:col-span-1"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-50 rounded-bl-[5rem] -mr-8 -mt-8 group-hover:bg-amber-100 transition-colors"></div>
          <div className="w-16 h-16 bg-amber-500 text-white rounded-full flex items-center justify-center text-2xl shadow-lg relative z-10 group-hover:scale-110 transition-transform">
            <i className="fas fa-chalkboard-teacher"></i>
          </div>
          <div className="relative z-10">
            <h3 className="text-xl md:text-2xl font-black text-slate-800 mb-2">Pengurusan Guru</h3>
            <p className="text-slate-500 text-xs leading-relaxed">Kemas kini senarai nama guru rasmi untuk kegunaan dropdown di borang rekod sesi.</p>
          </div>
          <div className="mt-4 flex items-center gap-2 text-amber-600 font-bold text-[10px] uppercase tracking-widest">
            Urus Guru <i className="fas fa-arrow-right group-hover:translate-x-1 transition-transform"></i>
          </div>
        </button>
      </div>
    </div>
  );

  if (view === 'home') {
    return (
      <div className="min-h-screen w-full bg-gradient-to-br from-indigo-900 via-indigo-800 to-violet-900 flex items-center justify-center p-4 relative overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-64 md:w-96 h-64 md:h-96 bg-emerald-500/20 rounded-full blur-[60px] md:blur-[100px] animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-64 md:w-96 h-64 md:h-96 bg-indigo-500/30 rounded-full blur-[60px] md:blur-[100px]"></div>

        {showPasswordPrompt && <PasswordPromptUI />}

        <div className="max-w-4xl w-full bg-white/10 backdrop-blur-2xl rounded-[2.5rem] md:rounded-[3rem] border border-white/20 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-700 relative">
          <button 
            onClick={() => setView('dashboard')}
            className="absolute top-6 right-6 md:top-8 md:right-8 w-10 h-10 flex items-center justify-center rounded-full bg-white/10 text-white/60 hover:bg-white/20 hover:text-white transition-all z-20"
          >
            <i className="fas fa-times text-lg"></i>
          </button>

          <div className="grid grid-cols-1 md:grid-cols-2">
            <div className="p-8 md:p-12 flex flex-col justify-center items-center md:items-start text-center md:text-left space-y-6">
              <div className="w-24 h-24 md:w-32 md:h-32 bg-white rounded-full shadow-2xl mb-2 overflow-hidden border-4 border-white/30 transition-transform duration-500 hover:scale-105">
                <img src={SCHOOL_LOGO_URL} alt="Logo KelaSI" className="w-full h-full object-cover" />
              </div>
              <h1 className="text-3xl md:text-5xl font-black text-white leading-[1.1] tracking-tight">
                Rekod <br />
                <span className="text-emerald-400">Kelas Suluh Ilmu <br className="hidden md:block"/> (KelaSI)</span>
              </h1>
              <p className="text-indigo-100 text-base md:text-lg font-black opacity-90 tracking-tight">SK NANGA TEMALAT, SONG, SARAWAK</p>
            </div>

            <div className="bg-white/5 p-8 md:p-12 flex flex-col justify-center space-y-3 md:space-y-4 border-t md:border-t-0 md:border-l border-white/10">
              <button onClick={() => setView('dashboard')} className="group flex items-center gap-4 md:gap-5 p-5 md:p-6 bg-white/10 hover:bg-white/20 rounded-2xl md:rounded-3xl border border-white/10 transition-all hover:scale-[1.02] active:scale-95 text-left">
                <div className="w-12 h-12 md:w-14 md:h-14 bg-indigo-500/30 rounded-full flex items-center justify-center text-white text-xl md:text-2xl group-hover:bg-indigo-50 transition-colors">
                  <i className="fas fa-chart-pie"></i>
                </div>
                <h3 className="text-lg md:text-xl font-bold text-white">Papan Pemuka</h3>
              </button>

              <button onClick={() => setView('new-session')} className="group flex items-center gap-4 md:gap-5 p-5 md:p-6 bg-white/10 hover:bg-white/20 rounded-2xl md:rounded-3xl border border-white/10 transition-all hover:scale-[1.02] active:scale-95 text-left">
                <div className="w-12 h-12 md:w-14 md:h-14 bg-emerald-500/30 rounded-full flex items-center justify-center text-white text-xl md:text-2xl group-hover:bg-emerald-500 transition-colors">
                  <i className="fas fa-plus-circle"></i>
                </div>
                <h3 className="text-lg md:text-xl font-bold text-white">Rekod Sesi KelaSI</h3>
              </button>

              <button onClick={() => handleViewChange('admin')} className="group flex items-center gap-4 md:gap-5 p-5 md:p-6 bg-white/10 hover:bg-white/20 rounded-2xl md:rounded-3xl border border-white/10 transition-all hover:scale-[1.02] active:scale-95 text-left">
                <div className="w-12 h-12 md:w-14 md:h-14 bg-amber-500/30 rounded-full flex items-center justify-center text-white text-xl md:text-2xl group-hover:bg-amber-500 transition-colors">
                  <i className="fas fa-user-shield"></i>
                </div>
                <h3 className="text-lg md:text-xl font-bold text-white">Akses Pentadbir</h3>
              </button>
            </div>
          </div>
          <div className="p-6 md:p-8 bg-black/15 text-center border-t border-white/5 space-y-1">
             <p className="text-white/80 text-[10px] md:text-xs font-black uppercase tracking-[0.2em] italic">Together We Are Stronger</p>
             <p className="text-white/40 text-[10px] md:text-xs font-medium tracking-widest uppercase">© 2026 SK Nanga Temalat</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden relative">
      {isMobileMenuOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-40 md:hidden" onClick={() => setIsMobileMenuOpen(false)}></div>
      )}
      <div className={`fixed inset-y-0 left-0 z-50 transform ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 transition-transform duration-300 ease-in-out`}>
        <Sidebar currentView={view as any} setView={handleViewChange} />
      </div>
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header 
          title={
            view === 'dashboard' ? 'Papan Pemuka' : 
            view === 'new-session' ? (editingSession ? 'Edit Rekod Sesi' : 'Rekod Sesi KelaSI') : 
            view === 'admin' ? 'Pusat Kawalan Pentadbir' :
            view === 'students' ? 'Pengurusan Murid' : 
            view === 'teachers' ? 'Pengurusan Guru' :
            view === 'history' ? 'Sejarah Sesi' : 'Akses Pentadbir'
          } 
          onMenuClick={() => setIsMobileMenuOpen(true)}
        />
        <main className="flex-1 overflow-y-auto p-4 md:p-8 relative custom-scrollbar">
          {showSuccessPopup && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 backdrop-blur-[2px] animate-in fade-in duration-300 px-4">
              <div className="bg-white p-6 md:p-8 rounded-[2rem] shadow-2xl border border-slate-100 max-w-sm w-full text-center relative animate-in zoom-in-95 duration-300">
                <button onClick={() => setShowSuccessPopup(false)} className="absolute top-5 right-5 w-8 h-8 flex items-center justify-center rounded-full bg-slate-50 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors">
                  <i className="fas fa-times"></i>
                </button>
                <div className="w-16 h-16 md:w-20 md:h-20 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl md:text-3xl shadow-inner border border-emerald-100">
                  <i className="fas fa-check-circle"></i>
                </div>
                <h3 className="text-xl md:text-2xl font-black text-slate-800 mb-2">Tahniah!</h3>
                <p className="text-slate-500 font-medium mb-8">Rekod Berjaya Disimpan</p>
                <button onClick={() => setShowSuccessPopup(false)} className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-bold shadow-lg shadow-emerald-500/30 hover:bg-emerald-600 transition-all active:scale-95">Tutup</button>
              </div>
            </div>
          )}

          {showPasswordPrompt && <PasswordPromptUI />}

          {view === 'dashboard' && (
            <Dashboard sessions={sessions} students={students} onNewSession={() => setView('new-session')} />
          )}
          {view === 'new-session' && (
            <SessionForm onSave={handleSaveSession} onCancel={() => {setEditingSession(null); setView('dashboard');}} students={students} teachers={teachers} initialData={editingSession} />
          )}
          {view === 'admin' && <AdminHub />}
          {view === 'history' && (
            <div className="space-y-6">
              <button onClick={() => setView('admin')} className="flex items-center gap-2 text-indigo-600 font-bold text-sm hover:underline"><i className="fas fa-arrow-left"></i> Kembali ke Akses Pentadbir</button>
              <SessionHistory sessions={sessions} students={students} onEdit={handleEditSession} onDelete={handleDeleteSession} />
            </div>
          )}
          {view === 'students' && (
            <div className="space-y-6">
              <button onClick={() => setView('admin')} className="flex items-center gap-2 text-indigo-600 font-bold text-sm hover:underline"><i className="fas fa-arrow-left"></i> Kembali ke Akses Pentadbir</button>
              <StudentManagement students={students} setStudents={setStudents} />
            </div>
          )}
          {view === 'teachers' && (
            <div className="space-y-6">
              <button onClick={() => setView('admin')} className="flex items-center gap-2 text-indigo-600 font-bold text-sm hover:underline"><i className="fas fa-arrow-left"></i> Kembali ke Akses Pentadbir</button>
              <TeacherManagement teachers={teachers} setTeachers={setTeachers} />
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default App;
