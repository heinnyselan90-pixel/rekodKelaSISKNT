
export type AttendanceStatus = 'present' | 'absent' | 'late';

export interface Student {
  id: string;
  name: string;
  grade: string;
}

export interface Teacher {
  id: string;
  name: string;
}

export interface AttendanceRecord {
  studentId: string;
  status: AttendanceStatus;
  note?: string;
}

export interface ExtraClassSession {
  id: string;
  date: string;
  subject: string;
  teacher: string;
  topic: string;
  grade: string; // Class year
  reflection: string;
  image?: string; // base64 string
  attendance: AttendanceRecord[];
}

export interface ClassStats {
  totalPresent: number;
  totalAbsent: number;
  totalLate: number;
  percentage: number;
}