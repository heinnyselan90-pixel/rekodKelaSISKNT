
import { Student, Teacher } from './types';

export const MOCK_STUDENTS: Student[] = [
  // Tahun 1
  { id: 't1-1', name: 'Audrey Riau anak Romeo Ray', grade: 'Tahun 1' },
  { id: 't1-2', name: 'Dominic Chua anak Lau', grade: 'Tahun 1' },
  { id: 't1-3', name: 'Eva Vionetta Ranchang anak Max Mike', grade: 'Tahun 1' },
  { id: 't1-4', name: 'Maczeus Malachy anak Matius', grade: 'Tahun 1' },
  { id: 't1-5', name: 'Marchella anak Jupita Meringgai', grade: 'Tahun 1' },
  { id: 't1-6', name: 'Rafael Immanuel anak Ricky', grade: 'Tahun 1' },
  { id: 't1-7', name: 'Valeric Laja anak Amy', grade: 'Tahun 1' },
  
  // Tahun 2
  { id: 't2-1', name: 'Adriella Amber anak Dominic', grade: 'Tahun 2' },
  { id: 't2-2', name: 'Darissa Sendu anak Ibrahim', grade: 'Tahun 2' },
  { id: 't2-3', name: 'Divsha Edrea anak Desmond', grade: 'Tahun 2' },
  { id: 't2-4', name: 'Iswandi Rayyan anak Susan', grade: 'Tahun 2' },
  { id: 't2-5', name: 'Liora Qisya anak Larry', grade: 'Tahun 2' },
  { id: 't2-6', name: 'Raphael Sim Chiew Yi', grade: 'Tahun 2' },
  { id: 't2-7', name: 'Rochester Rooyen anak Kurai', grade: 'Tahun 2' },
  { id: 't2-8', name: 'Spencer Reuel Itang Anak Rayenyson Chunggat', grade: 'Tahun 2' },
  { id: 't2-9', name: 'Valerie Naja anak Amy', grade: 'Tahun 2' },

  // Tahun 3
  { id: 't3-1', name: 'Analia Aviana anak Aida', grade: 'Tahun 3' },
  { id: 't3-2', name: 'Avesster Byron anak Jemary', grade: 'Tahun 3' },
  { id: 't3-3', name: 'Evyonne Marcell Mias anak Max Mike', grade: 'Tahun 3' },
  { id: 't3-4', name: 'Fellissia anak Arthur', grade: 'Tahun 3' },
  { id: 't3-5', name: 'Francisca Filecia Ayang anak Jeffery', grade: 'Tahun 3' },
  { id: 't3-6', name: 'Irien Wedyanayan anak Ibrahim', grade: 'Tahun 3' },
  { id: 't3-7', name: 'Jaszrel Megong anak Ricki', grade: 'Tahun 3' },
  { id: 't3-8', name: 'Kathlene Mell anak Vincent', grade: 'Tahun 3' },
  { id: 't3-9', name: 'Racheal Dujong anak Beth', grade: 'Tahun 3' },
  { id: 't3-10', name: 'Ryan Ading anak Romeo Ray', grade: 'Tahun 3' },
  { id: 't3-11', name: 'Sharly Evylia anak Puyu', grade: 'Tahun 3' },
  { id: 't3-12', name: 'Sun anak Enturan', grade: 'Tahun 3' },
  { id: 't3-13', name: 'Vennedict Kentzie Gerson Lusat', grade: 'Tahun 3' },
  { id: 't3-14', name: 'Zackyeus Rovisson Ulleh anak Wilson', grade: 'Tahun 3' },

  // Tahun 4
  { id: 't4-1', name: 'Adriell Andin anak Richie', grade: 'Tahun 4' },
  { id: 't4-2', name: 'Allysseanie Mina anak Francis', grade: 'Tahun 4' },
  { id: 't4-3', name: 'Angeline Agustine', grade: 'Tahun 4' },
  { id: 't4-4', name: 'Betty anak Nicholas', grade: 'Tahun 4' },
  { id: 't4-5', name: 'Felicia Hety anak Norny', grade: 'Tahun 4' },
  { id: 't4-6', name: 'Hierro Arhsay anak Nick Hassler', grade: 'Tahun 4' },
  { id: 't4-7', name: 'Jaslyn Lambih anak Jay', grade: 'Tahun 4' },
  { id: 't4-8', name: 'Lyennisa anak Edwin', grade: 'Tahun 4' },
  { id: 't4-9', name: 'Mary Anne anak Vincent', grade: 'Tahun 4' },
  { id: 't4-10', name: 'Melldella Nayun anak Augustine', grade: 'Tahun 4' },
  { id: 't4-11', name: 'Ruthfella Sim Xiao Shuang', grade: 'Tahun 4' },
  { id: 't4-12', name: 'Zionathan Raphael Insol anak Wilson', grade: 'Tahun 4' },

  // Tahun 5
  { id: 't5-1', name: 'Agnes Jirin anak Loyd Alester', grade: 'Tahun 5' },
  { id: 't5-2', name: 'Alponsious Emmanuel anak Francis', grade: 'Tahun 5' },
  { id: 't5-3', name: 'Cherish Indan anak Amy', grade: 'Tahun 5' },
  { id: 't5-4', name: 'Clerence anak Platini', grade: 'Tahun 5' },
  { id: 't5-5', name: 'Diffyna Dhaoun Ngo', grade: 'Tahun 5' },
  { id: 't5-6', name: 'Gabriel Bryan anak Radin', grade: 'Tahun 5' },
  { id: 't5-7', name: 'Jesquila Maya anak Jimbun', grade: 'Tahun 5' },
  { id: 't5-8', name: 'Leticia Qeira anak Larry', grade: 'Tahun 5' },
  { id: 't5-9', name: 'Lyia Thina anak Thomas', grade: 'Tahun 5' },
  { id: 't5-10', name: 'Roderrick Tajak anak Alysis', grade: 'Tahun 5' },
  { id: 't5-11', name: 'Stevjackson Danny anak John', grade: 'Tahun 5' },
  { id: 't5-12', name: 'Tiara Lia anak Catherine', grade: 'Tahun 5' },
  { id: 't5-13', name: 'Yhanieysha Janam anak Rapielsi Jhidyanie', grade: 'Tahun 5' },

  // Tahun 6
  { id: 't6-1', name: 'Albert Jhoanes anak Alin', grade: 'Tahun 6' },
  { id: 't6-2', name: 'Domenic Jimbat anak Rengga', grade: 'Tahun 6' },
  { id: 't6-3', name: 'Gideoan Edthan anak Muran', grade: 'Tahun 6' },
  { id: 't6-4', name: 'Hernandez Nirau anak Jay', grade: 'Tahun 6' },
  { id: 't6-5', name: 'Herry Upin anak Ujai', grade: 'Tahun 6' },
  { id: 't6-6', name: 'Jackson Linggie anak Baling', grade: 'Tahun 6' },
  { id: 't6-7', name: 'Justin anak Ricki', grade: 'Tahun 6' },
  { id: 't6-8', name: 'Liong King Soon', grade: 'Tahun 6' },
  { id: 't6-9', name: 'Nur Husna binti Muhammad Arif Aiman', grade: 'Tahun 6' },
  { id: 't6-10', name: 'Petrus Daniel anak Steward', grade: 'Tahun 6' },
  { id: 't6-11', name: 'Phillomena Ula anak Lau', grade: 'Tahun 6' },
  { id: 't6-12', name: 'Qalexsia Syafika anak Ricky', grade: 'Tahun 6' },
  { id: 't6-13', name: 'Sebastian Anyoh anak Kunchie', grade: 'Tahun 6' },
  { id: 't6-14', name: 'Victor Varreth anak Nutup @ Enyap', grade: 'Tahun 6' },
];

export const SUBJECTS = [
  'Bahasa Melayu',
  'English',
  'Mathematics (DLP)',
  'Science (DLP)'
];

export const CLASSES = [
  'Tahun 1',
  'Tahun 2',
  'Tahun 3',
  'Tahun 4',
  'Tahun 5',
  'Tahun 6'
];

export const MOCK_TEACHERS: Teacher[] = [
  { id: 'tea-1', name: 'Amy anak Tabol' },
  { id: 'tea-2', name: 'Asmah binti Atoi' },
  { id: 'tea-3', name: 'Bryan Chiong' },
  { id: 'tea-4', name: 'Elizabeth Pinin anak Ahmad' },
  { id: 'tea-5', name: 'Goldie anak Gayah' },
  { id: 'tea-6', name: 'Heinny anak Selan' },
  { id: 'tea-7', name: 'Jaclyn anak Berandah' },
  { id: 'tea-8', name: 'Elnah Sinusi' },
  { id: 'tea-9', name: 'Kheerthiga a/p Thiagaraja' },
  { id: 'tea-10', name: 'Lily anak Ajut' },
  { id: 'tea-11', name: 'Muhd. Asyran bin Solah' },
  { id: 'tea-12', name: 'Nur Muhd. Naqiyuddin bin Normisham' },
  { id: 'tea-13', name: 'Nurul Izza Tiong binti Abdullah' },
  { id: 'tea-14', name: 'Patrick Tama' },
  { id: 'tea-15', name: 'Robin Sim Kang Joo' },
  { id: 'tea-16', name: 'Romeo Ray anak Balong' },
  { id: 'tea-17', name: 'Santiago anak Layup' }
];